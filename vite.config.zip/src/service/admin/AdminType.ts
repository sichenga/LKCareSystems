// 用户登录 /api/auth/login
export interface Login {
  username: string
  pwd: string
}
