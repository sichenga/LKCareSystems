<template>
    <div>
        入院记录 / 出
    </div>
</template>
<script lang="ts" setup>
</script>
<style lang="less" scoped>
</style>