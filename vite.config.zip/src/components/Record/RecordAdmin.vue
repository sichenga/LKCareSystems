<template>
    <div>
        健康档案 // 基础信息
    </div>
</template>
<script lang="ts" setup>
</script>
<style lang="less" scoped>
</style>