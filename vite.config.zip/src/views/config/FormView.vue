<template>
   <!-- dialog写在config文件夹下 -->
   <div>表单组件</div>
</template>

<script lang='ts' setup>

</script>

<style scoped>

</style>