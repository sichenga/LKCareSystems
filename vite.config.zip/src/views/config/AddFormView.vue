<template>
      <!-- dialog写在config文件夹下 -->
   <div>增加表单</div>
</template>

<script lang='ts' setup>

</script>

<style scoped>

</style>