<template>
  <!-- dialog写在market文件夹下 -->
  新增入院申请
  </template>
<script lang="ts" setup>
</script>
<style lang="less" scoped></style>
