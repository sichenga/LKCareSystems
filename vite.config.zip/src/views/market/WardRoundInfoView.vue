<template>

   <!-- <div>行政查房详情</div> -->
   <el-card style="max-width: 100%">
      <div class="live">
         <div class="title">
            <span>▋</span> 生活护理
         </div>
         <div class="info">
            <div class="left">
               情况概要
            </div>
            <div class="right">
               Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida
               dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque
               penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra
               vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget odio. Lorem ipsum dolor sit amet,
               consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit
            </div>
         </div>
         <div class="info">
            <div class="left">
               处理意见
            </div>
            <div class="right">
               Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida
               dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque
               penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra
               vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget odio. Lorem ipsum dolor sit amet,
               consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit
            </div>
         </div>
      </div>
      <div class="hospital">
         <div class="title">
            <span>▋</span> 医疗护理
         </div>
         <div class="info">
            <div class="left">
               情况概要
            </div>
            <div class="right">
               Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida
               dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque
               penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra
               vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget odio. Lorem ipsum dolor sit amet,
               consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit
            </div>
         </div>
         <div class="info">
            <div class="left">
               处理意见
            </div>
            <div class="right">
               Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida
               dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque
               penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra
               vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget odio. Lorem ipsum dolor sit amet,
               consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit
            </div>
         </div>
      </div>
      <div class="hospital">
         <div class="title">
            <span>▋</span> 后勤保障
         </div>
         <div class="info">
            <div class="left">
               情况概要
            </div>
            <div class="right">
               Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida
               dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque
               penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra
               vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget odio. Lorem ipsum dolor sit amet,
               consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit
            </div>
         </div>
         <div class="info">
            <div class="left">
               处理意见
            </div>
            <div class="right">
               Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida
               dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque
               penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra
               vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget odio. Lorem ipsum dolor sit amet,
               consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit
            </div>
         </div>
      </div>
      <div class="hospital">
         <div class="title">
            <span>▋</span> 安全隐患
         </div>
         <div class="info">
            <div class="left">
               情况概要
            </div>
            <div class="right">
               Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida
               dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque
               penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra
               vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget odio. Lorem ipsum dolor sit amet,
               consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit
            </div>
         </div>
         <div class="info">
            <div class="left">
               处理意见
            </div>
            <div class="right">
               Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida
               dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque
               penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra
               vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget odio. Lorem ipsum dolor sit amet,
               consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit
            </div>
         </div>
      </div>
      <div class="hospital">
         <div class="title">
            <span>▋</span> 意见或建议
         </div>
         <div class="info">
            <div class="left">
               情况概要
            </div>
            <div class="right">
               Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida
               dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque
               penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra
               vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget odio. Lorem ipsum dolor sit amet,
               consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit
            </div>
         </div>
         <div class="info">
            <div class="left">
               处理意见
            </div>
            <div class="right">
               Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida
               dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque
               penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra
               vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget odio. Lorem ipsum dolor sit amet,
               consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit
            </div>
         </div>
      </div>
      
      <div class="btn">
         <el-button>取消</el-button>
         <el-button type="primary">确认</el-button>
      </div>
   </el-card>

      <!-- dialog写在market文件夹下 -->

</template>

<script lang='ts' setup>

</script>

<style lang="less" scoped>

.live {
   width: 800px;

   .title {
      height: 50px;
      line-height: 50px;

      span {
         color: #529bfd;
      }

      font-weight: bold;
   }

   .info {
      display: flex;
      margin-top: 20px;

      .left {
         width: 100px;
      }

      .right {
         width: 600px;
      }

   }
}

.hospital {
   width: 800px;
   margin-top: 100px;
   .title {
      height: 50px;
      line-height: 50px;

      span {
         color: #529bfd;
      }

      font-weight: bold;
   }

   .info {
      display: flex;
      margin-top: 20px;

      .left {
         width: 100px;
      }

      .right {
         width: 600px;
      }

   }
}
.btn {
   width: 200px;
   height: 50px;
  margin: 100px auto 0;
}
</style>