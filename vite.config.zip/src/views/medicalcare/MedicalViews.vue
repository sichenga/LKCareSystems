<template>
        <!-- dialog写在medicalcare文件夹下 -->
    体检报告
</template>
<script lang="ts" setup>
</script>
<style lang="less" scoped>
</style>