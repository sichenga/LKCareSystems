<template>
         <!-- dialog写在medicalcare文件夹下 -->
     查看体检报告详情
</template>
<script lang="ts" setup>
</script>
<style lang="less" scoped>
</style>
