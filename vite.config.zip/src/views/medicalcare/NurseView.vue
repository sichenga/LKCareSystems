<template>
       <!-- dialog写在medicalcare文件夹下 -->
   <el-tabs type="card" class="demo-tabs">
      <el-tab-pane label="血压记录" name="first">
         血压记录
      </el-tab-pane>
      <el-tab-pane label="血糖记录" name="second">
         血糖记录
      </el-tab-pane>
      <el-tab-pane label="体温记录" name="third">
         体温记录
      </el-tab-pane>

   </el-tabs>

</template>
<script lang="ts" setup>


</script>
<style lang="less" scoped>
</style>