// import request from "@/utils/request";
// import {CaptchaResult, LoginData, LoginResult} from "./model";
//
// class AuthAPI {
//   /**
//    * 登录API
//    *
//    * @param data {LoginData}
//    * @returns
//    */
//   static login(data: LoginData) {
//     return request<any, LoginResult>({
//       url: "/api/auth/login",
//       method: "post",
//       data,
//       headers: {
//         "Content-Type": "application/json",
//       },
//     });
//   }

/**
 * 注销API
 */
// static logout() {
//   return request({
//     url: "/api/v1/auth/logout",
//     method: "delete",
//   });
// }

/**
 * 获取验证码
 */
//   static getCaptcha() {
//     return request<any, CaptchaResult>({
//       url: "/api/v1/auth/captcha",
//       method: "get",
//     });
//   }
// }

// export default AuthAPI;
