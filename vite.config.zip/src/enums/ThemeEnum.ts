/**
 * 主题枚举
 */
export const enum ThemeEnum {
  /**
   * 明亮主题
   */
  LIGHT = "light",
  /**
   * 暗黑主题
   */
  DARK = "dark",

  /**
   * 系统自动
   */
  AUTO = "auto",
}
