// 封装表格
export interface TableItem {
  label: string;
  prop: string;
  width?: string;
}
