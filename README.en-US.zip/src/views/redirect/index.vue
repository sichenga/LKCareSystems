<script lang="ts" setup></script>

<template>404;</template>

<style lang="less" scoped></style>
