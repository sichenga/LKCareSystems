const logo = "https://s21.ax1x.com/2024/05/07/pkEqS4P.png";
const loginback = "https://s21.ax1x.com/2024/05/07/pkEIc4O.jpg";
const code = "https://s21.ax1x.com/2024/05/07/pkETPeI.png";
const homelogin = "https://s21.ax1x.com/2024/05/07/pkEqS4P.png";
export { logo, loginback, code, homelogin };
